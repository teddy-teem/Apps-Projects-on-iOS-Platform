//
//  ViewController.m
//  Ritu's Coffee
//
//  Created by JAHID HASAN on 12/2/17.
//  Copyright (c) 2017 Vutu's. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)calculateButtonPressed:(id)sender {
    
    NSLog(@"Calculate Pressed");
    
    long long int age = [[self.ageTextField text] integerValue];
    long long int weight = [[self.weightTextField text] integerValue];
    float water = [[self.waterTextField text] floatValue];
    float ratio = [[self.ratioTextField text] floatValue];
    float temp_ratio;
    
    NSLog(@"Age: %lld Weight: %lld water: %f ratio: %f", age, weight, water, ratio);
    
    float coffee = 0;
    coffee = water / ratio;
    NSLog(@"Coffee: %f", coffee);
    
    NSString *coffeeText = [NSString stringWithFormat:@"%f", coffee];
    self.coffeeTextField.text = coffeeText;
    
    if (age<=15)
    {
        NSString *messageText = [NSString stringWithFormat:@"You shouldn't drink coffee 😑"];
        self.messageTextField.text = messageText;
    }
    else if (weight>85)
    {
        NSString *messageText = [NSString stringWithFormat:@"Don't mixed suger in coffee 😣"];
        self.messageTextField.text = messageText;
    }
    else if (age>70)
    {
        NSString *messageText = [NSString stringWithFormat:@"You shouldn't drink coffee 😐"];
        self.messageTextField.text = messageText;
    }
    else
    {
        NSString *messageText = [NSString stringWithFormat:@"Mew 👩🏻, Meew👩🏻, mew👩🏻"];
        self.messageTextField.text = messageText;
    }
    
    temp_ratio = water / coffee;
    if (temp_ratio>60 && ratio<100)
    {
        NSString *statusText = [NSString stringWithFormat:@"Normal"];
        self.statusTextField.text = statusText;
    }
    else if (temp_ratio >100)
    {
        NSString *statusText = [NSString stringWithFormat:@"Too Light"];
        self.statusTextField.text = statusText;
    }
    else
    {
        NSString *statusText = [NSString stringWithFormat:@"Strong"];
        self.statusTextField.text = statusText;
    }
    


}
@end
