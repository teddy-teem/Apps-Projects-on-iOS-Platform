//
//  main.m
//  Ritu's Coffee
//
//  Created by JAHID HASAN on 12/2/17.
//  Copyright (c) 2017 Vutu's. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
